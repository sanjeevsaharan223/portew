<?php



echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal">Apply Here</button>';

?>