-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 10, 2019 at 08:06 AM
-- Server version: 10.1.29-MariaDB-6+b1
-- PHP Version: 7.2.9-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admission2018`
--

-- --------------------------------------------------------

--
-- Table structure for table `control`
--

CREATE TABLE `control` (
  `applicationNo` mediumint(10) NOT NULL,
  `state` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `control`
--

INSERT INTO `control` (`applicationNo`, `state`) VALUES
(15, 7);

-- --------------------------------------------------------

--
-- Table structure for table `personaldetails`
--

CREATE TABLE `personaldetails` (
  `applicationNo` mediumint(10) NOT NULL,
  `fathername` varchar(200) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `course` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `disability` varchar(10) NOT NULL,
  `typeofdisability` varchar(10) NOT NULL,
  `otherdisability` varchar(10) NOT NULL,
  `entrancepaper` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `applicationNo` mediumint(10) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `mobileno` bigint(10) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` longtext NOT NULL,
  `creation_time` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`applicationNo`, `fullname`, `mobileno`, `email`, `password`, `creation_time`) VALUES
(1, 'sanjeev', 9812535422, 'sanjeev@gmail.com', 'hello', '2019-06-06 00:00:00.000000'),
(5, 'asd', 9812523666, 'ssingh2525@nic.in', '123456', '2019-06-07 15:17:57.000000'),
(6, 'asdss', 9813523666, 'sssingh2525@nic.in', '123456', '2019-06-07 16:05:05.000000'),
(7, 'asd', 9812823666, 'ssingh82525@nic.in', '123456', '2019-06-07 16:05:38.000000'),
(8, 'asd', 9812824666, 'ssinghs82525@nic.in', '123456', '2019-06-07 16:07:17.000000'),
(9, 'asd', 9822523666, 'ssisngh2525@nic.in', '123456', '2019-06-07 16:22:21.000000'),
(10, 'asd', 9222523666, 'sasisngh2525@nic.in', '123456', '2019-06-07 16:23:19.000000'),
(11, 'asd', 9522523666, 'sasissangh2525@nic.in', '123456', '2019-06-07 16:33:45.000000'),
(12, 'asd', 7522523666, 'saassissangh2525@nic.in', '123456', '2019-06-07 16:34:46.000000'),
(13, 'aa', 9632587410, 'sasa@g.com', '123456', '2019-06-07 16:35:35.000000'),
(14, 'aa', 9632527410, 'saasa@g.com', '123456', '2019-06-07 16:36:05.000000'),
(15, 'asdfasf', 1234522223, 'a@f.com', '123456', '2019-06-07 16:36:42.000000'),
(16, 'sanjeev', 9812556254, 's@gp.com', '123456', '2019-06-07 16:57:59.000000'),
(17, 'sanjeev', 9812534522, 'sanjeefsddfv@gmail.com', '123456', '2019-06-07 17:34:57.000000'),
(18, 'sa', 9812535421, 's@g.vom', '123456', '2019-06-09 07:51:38.000000');

-- --------------------------------------------------------

--
-- Table structure for table `state_list`
--

CREATE TABLE `state_list` (
  `id` int(10) UNSIGNED NOT NULL,
  `state` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `state_list`
--

INSERT INTO `state_list` (`id`, `state`) VALUES
(1, 'ANDAMAN AND NICOBAR ISLANDS'),
(2, 'ANDHRA PRADESH'),
(3, 'ARUNACHAL PRADESH'),
(4, 'ASSAM'),
(5, 'BIHAR'),
(6, 'CHATTISGARH'),
(7, 'CHANDIGARH'),
(8, 'DAMAN AND DIU'),
(9, 'DELHI'),
(10, 'DADRA AND NAGAR HAVELI'),
(11, 'GOA'),
(12, 'GUJARAT'),
(13, 'HIMACHAL PRADESH'),
(14, 'HARYANA'),
(15, 'JAMMU AND KASHMIR'),
(16, 'JHARKHAND'),
(17, 'KERALA'),
(18, 'KARNATAKA'),
(19, 'LAKSHADWEEP'),
(20, 'MEGHALAYA'),
(21, 'MAHARASHTRA'),
(22, 'MANIPUR'),
(23, 'MADHYA PRADESH'),
(24, 'MIZORAM'),
(25, 'NAGALAND'),
(26, 'ORISSA'),
(27, 'PUNJAB'),
(28, 'PONDICHERRY'),
(29, 'RAJASTHAN'),
(30, 'SIKKIM'),
(31, 'TAMIL NADU'),
(32, 'TRIPURA'),
(33, 'UTTARAKHAND'),
(34, 'UTTAR PRADESH'),
(35, 'WEST BENGAL'),
(36, 'TELANGANA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `control`
--
ALTER TABLE `control`
  ADD PRIMARY KEY (`applicationNo`);

--
-- Indexes for table `personaldetails`
--
ALTER TABLE `personaldetails`
  ADD PRIMARY KEY (`applicationNo`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`applicationNo`);

--
-- Indexes for table `state_list`
--
ALTER TABLE `state_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `applicationNo` mediumint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `state_list`
--
ALTER TABLE `state_list`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
