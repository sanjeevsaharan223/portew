<?php
session_start();
include 'main2.php';
include 'connect.php';
include 'crypt.php';

/*
echo $_SESSION["token"];
echo "<br>";
echo $_SESSION["applicationNo"];

*/	

if(isset($_GET['q'])  && (((time()-decrypt($_GET['q'],$key))/60)<10) && isset($_COOKIE["type"]))
{
				

		echo $_SESSION["token"];
		echo $_COOKIE["type"];
		echo "<br>";
		echo $_SESSION["applicationNo"];
		$login_status = $_SESSION["applicationNo"];

				if(isset($login_status))	
				{
					$_SESSION["index"] ="allowed";
					echo "string inside login";
					include 'index.php';
				}

				else{

					echo "logged out";
				}
}

else
{
	session_destroy();
	echo "string";
	 
		// show here session expired message.
	//header("Location:login.php");
}

?>