<?php
session_start();
include 'connect.php';
include 'crypt.php';

$error = array();


if($_POST['captchalogin'] == $_SESSION["captcha_logincode"])
{
	$applicationNo = $_POST['applicationNo'];
	$password = $_POST['passwd'];


	$query3 = "SELECT * FROM `signup` WHERE `applicationNo`='$applicationNo' AND `password`='$password'";

	$result = mysqli_query($link, $query3);
	$row = mysqli_fetch_array($result);
	
	if(mysqli_num_rows($result)>0)
			{
				$current = time();
				$token = encrypt($current,$key);
				$_SESSION["token"] = $token;
				$_SESSION["applicationNo"] = $row ["applicationNo"];
				$error['token'] = "http://localhost/portnew/welcome.php"."?q=".$token;
				setcookie("type",$token, time()+3600);
				setcookie("secure",encrypt($row["applicationNo"],$key), time()+3600);
				echo json_encode($error);

			}

	else {
			  $error['errorlogin'] = "Entered combination of application No and password is incorrect";
			  echo json_encode($error);
			}

}

else {
  $error['errlogcaptcha'] = "Catpcha code entered is incorrect";
  echo json_encode($error);
  
}




?>
