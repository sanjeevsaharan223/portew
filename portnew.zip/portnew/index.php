<?php
session_start();
include 'crypt.php';
$applicationNo = decrypt($_COOKIE["secure"],$key);

include 'connect.php';
$query5 = "SELECT * FROM `signup` WHERE `applicationNo`='$applicationNo'";
$result = mysqli_query($link,$query5);
$row = mysqli_fetch_array($result);

$query6 = "SELECT * FROM `control` WHERE `applicationNo`='$applicationNo'";
$result1 = mysqli_query($link,$query6);
$row2 = mysqli_fetch_array($result1);
$state = $row2['state'];

//set to isset($_SESSION["index"])
if(isset($_SESSION["index"]) && isset($_COOKIE["type"]))
{
	echo "inside index ";
	include 'main2.php';
}

else
{
	header("Location:login.php");
}


?>

<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
<div class="container">
	<div class="row">
		<div class="card col-md-6" style="height: 500px;">
			<div class="card-body bg-white shadow-lg bg-white rounded" >
				<h5 class="card-title bg-transparent text-center text-info ">PART-1 REGISTRATION</h5>
				<div class="card">
					<div class="card-body">
							<table class="table">
							  <thead>
							    <tr>
							      <th scope="col">Step</th>
							      <th scope="col">Particulars</th>
							      <th scope="col">Action</th>
							      
							    </tr>
							  </thead>
							  <tbody>
							    <tr>
							      <th scope="row">1</th>
							      <td>Personal Details</td>
							      <td><?php
							      	if ($state < 1){
										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal">Apply Here</button>';
							      	}
							      	elseif ($state>=5){
										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal" disabled>Apply Here</button>';
							      	}
									elseif($state<5){

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal">Update</button>';

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal">View</button>';
									}


									?></td>
							      
							    </tr>
							    <tr>
							      <th scope="row">2</th>
							      <td>Contact and Address Details</td>
							      <td><?php
							      	if ($state < 1 || $state >=5){
							      		echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#contactaddress" disabled>Apply Here</button>';
							      	}
							      	elseif ($state ==1 ){
										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#contactaddress">Apply Here</button>';
							      	}
									elseif($state<5){

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#contactaddress">Update</button>';

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#contactaddress">View</button>';
									}

									?></td>
							      
							    </tr>
							    <tr>
							      <th scope="row">3</th>
							      <td>Educational Details</td>
							      <td><?php
							      	if ($state <2 || $state>=5){
							      		echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#education" disabled>Apply Here</button>';
							      	}
							      	elseif ($state ==2 ){
										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#education" >Apply Here</button>';
							      	}
									else{

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#education">Update</button>';

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#education">View</button>';
									}

									?></td>
							      
							    </tr>
							    <tr>
							      <th scope="row">4</th>
							      <td>Picture Sign & Documents Upload</td>
							      <td><?php 
							      if ($state <3 || $state >=5){
							      		echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#document" disabled>Apply Here</button>';
							      	}
							      	elseif ($state ==3 ){
										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#document" >Apply Here</button>';
							      	}
									else{

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#document">Update</button>';

										echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#document">View</button>';
									}

							      ?></td>
							      
							    </tr>
							  </tbody>
							</table>
					</div>
				</div>
				<div class="text-center">
					<!--<a class="btn btn-primary btn-block" href="#" role="button">APPLY</a>-->
					<?php
					if ($state >=5 )
					{
						echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal" disabled>View</button>';
					}
					elseif($state < 4){
						echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal" disabled>View</button>';
					}
					elseif($state == 4){
						echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal" >View</button>';
					}
					
					 ?>
					
				</div>

			</div>
		</div>

		<div class="card col-md-6">
			<div class="card-body bg-white shadow-lg bg-white rounded">
				<h5 class="card-title bg-transparent text-center text-info">PART-2 REGISTERATION</h5>
				<div class="card">
					<div class="card-body">
									<table class="table">
									  <thead>
									    <tr>
									      <th scope="col">Step</th>
									      <th scope="col">Particulars</th>
									      <th scope="col">Action</th>
									      
									    </tr>
									  </thead>
									  <tbody>
									    <tr>
									      <th scope="row">1</th>
									      <td>Payment Details</td>
									      <td><?php
												if ($state < 5)
												{
													echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal" disabled>View</button>';
												}
												elseif ($state == 5)
												{
													echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal">View</button>';
												}
												elseif($state >5 && $state <7){
													echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal">View</button>';
												}
												else {
													echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal" disabled>View</button>';
												}
												 ?>
												 	
					 </td>
									      
									    </tr>

									  </tbody>
									</table>
									<div class="text-center"><?php
										if ($state >= 7 || $state <6)
												{
													echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal" disabled>View</button>';
												}
										else
												{
													echo '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#personal">View</button>';
												}

									  ?>						
									  </div>


					</div>
				</div>


			</div>

		</div>
	</div>
</div>

<!--personal details -->
<div class="modal fade" id="personal" tabindex="-1" role="dialog" aria-labelledby="personalModal" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content ">
      <div class="modal-header shadow-none ">
        <h5 class="modal-title text-warning " id="personalModal">Personal Details of candidate</h5>
        <div id="errors"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div id="info"></div>
      <div class="modal-body">
	           	<form action="" method="POST" id="personalform">
								<div class="row">
										<div class="form-group col-4">
												<label for="fullname">Full Name(as per records)</label>
				                            <input class="form-control" placeholder="Enter your full name" name="fullname" type="text" autocomplete="off" required="true" value="<?php echo $row['fullname']; ?>" disabled>
				                            <span class="error_form" id="errorfullname"></span>
			                        	</div>

										<div class="form-group col-4">
												<label for="fathername">Father Name</label>
				                            <input class="form-control" placeholder="Father Name" name="fathername" type="text" autocomplete="off" id="fathername" required="true">
				                            <span class="error_form" id="errorfathername"></span>
			                            </div>

			                            <div class="form-group col-4">
												<label for="mobile">Nationality</label>
				                            <select class="form-control">
		  										<option>Indian</option>
		  										<option>Non-Resident Indian</option>
		  										<option>Foreign National</option>
											</select>
				                            <span class="error_form" id="errornationality"></span>
			                            </div>
			                    </div>

	                        	
	                        	<div class="form-group row">
	                        		<div class="form-group col-4">
												<label for="course">Course applying for:</label>
				                            <select class="form-control">
		  										<option>Select Course</option>
		  										<option>M.Ed.SE(VI)</option>
		  										<option>B.Ed.SE(VI)</option>
		  										<option>P.G.D.R.P</option>
											</select>
				                            <span class="error_form" id="errorcourse"></span>
			                        </div>
			                        <div class="form-group col-4">
												<label for="category">Category</label>
				                            <select class="form-control">
		  										<option>Select Category</option>
		  										<option>SC</option>
		  										<option>ST</option>
		  										<option>OBC</option>
		  										<option>GENERAL</option>
		  										<option>GENERAL(EWS)</option>
											</select>
				                            <span class="error_form" id="errorcategory"></span>
			                        </div>

			                  		<div class="form-group col-4">
												<label for="sex">Sex</label>
				                            <select class="form-control">
		  										<option>Select</option>
		  										<option>Male</option>
		  										<option>Female</option>

											</select>
				                            <span class="error_form" id="errorcategory"></span>
			                        </div>
	                        	</div>

								<div class="form-group row">
	                        		<div class="form-group col-4">
												<label for="disability">Disability</label>
				                            <select class="form-control">
		  										<option>Select</option>
		  										<option>Yes</option>
		  										<option>No</option>
		  									</select>
				                            <span class="error_form" id="errorcourse"></span>
			                        </div>
			                        <div class="form-group col-4">
												<label for="category">Type of Disability</label>
				                            <select class="form-control">
		  										<option>Select</option>
		  										<option>V.I</option>
		  										<option>H.I</option>
		  										<option>O.H</option>
		  										<option>Other</option>
											</select>
				                            <span class="error_form" id="errorcategory"></span>
			                        </div>

			                        <div class="form-group col-4">
												<label for="otherdisability">Please specify</label>
				                            <input class="form-control" placeholder="" name="otherdisability" type="text" autocomplete="off" id="otherdisability" required="true">
				                            <span class="error_form" id="errorfathername"></span>
			                        </div>

											                  		
	                        	</div>

	                        	<div class="form-group col-4">
												<label for="category">Entrance Paper Required</label>
				                            <select class="form-control">
		  										<option>Select</option>
		  										<option>Braille</option>
		  										<option>Large Print</option>
		  										<option>Normal Print</option>
		  										
											</select>
				                            <span class="error_form" id="errorcategory"></span>
			                    </div>


								
	                        	<div class="text-center">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        						<button type="button" class="btn btn-primary" name="registerbutton" id="registerbutton">Register</button>
	        			</div>
					</form>
						
      </div>
    </div>
</div>
</div>

<!-- Contact Details -->
<div class="modal fade" id="contactaddress" tabindex="-1" role="dialog" aria-labelledby="personalModal" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content ">
      <div class="modal-header shadow-none ">
        <h5 class="modal-title text-warning " id="personalModal">Contact & Address Details of candidate</h5>
        <div id="errors"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div id="info"></div>
      <div class="modal-body">
	           	<form action="" method="POST" id="personalform">
								<div class="row">
										<div class="form-group col-4">
												<label for="houseno">House No./Flat No.</label>
				                            <input class="form-control" placeholder="House No/Flat No." name="houseno" type="text" autocomplete="off" required="true">
				                            <span class="error_form" id="errorhouse"></span>
			                        	</div>

										<div class="form-group col-4">
												<label for="street">Street</label>
				                            <input class="form-control" placeholder="Street" name="street" type="text" autocomplete="off" id="street" required="true">
				                            <span class="error_form" id="errorstreet"></span>
			                            </div>

			                            
			                    </div>

	                        	
	                        	<div class="form-group row">
	                        		<div class="form-group col-4">
												<label for="city">City/Village</label>
				                            <input class="form-control" placeholder="city" name="street" type="text" autocomplete="off" id="city" required="true">
				                            <span class="error_form" id="errorcity"></span>
			                        </div>

			                        

			                  		<div class="form-group col-4">
												<label for="state">State</label>
				                            <select class="form-control">
				                            	<?php
				                            	$query5 = "SELECT * FROM `state_list`";
				                            	$result = mysqli_query($link, $query5);
				                            	while ($row1 = mysqli_fetch_array($result)) {
				                            		echo "<option>".$row1['state']."</option>";

				                            	}

				                            	?>


											</select>
				                            <span class="error_form" id="errorstate"></span>
			                        </div>

			                        <div class="form-group col-4">
												<label for="pincode">Pincode</label>
				                            <input class="form-control" placeholder="Pincode" name="pincode" type="text" autocomplete="off" id="pincode" required="true">
				                            <span class="error_form" id="errorpincode"></span>
			                        </div>
	                        	</div>

	                        	<div class="form-group row">
	                        		<div class="form-group col-4">
												<label for="fullname">Adhar No.</label>
				                            <input class="form-control" placeholder="Enter your adhar number" name="adhar" type="text" autocomplete="off" required="true" >
				                            <span class="error_form" id="errorfullname"></span>
			                        </div>

			                       	<div class="form-group col-4">
												<label for="fullname">Mobile No.</label>
				                            <input class="form-control" placeholder="Enter your mobile number" name="mobileno" type="text" autocomplete="off" required="true" value="<?php echo $row['mobileno']; ?>" disabled>
				                            <span class="error_form" id="errorfullname"></span>
			                        </div>

			                        <div class="form-group col-4">
												<label for="email">E-mail</label>
				                            <input class="form-control" placeholder="E-mail" name="email" type="text" autocomplete="off" required="true" value="<?php echo $row['email']; ?>" disabled>
				                            <span class="error_form" id="erroremail"></span>
			                        </div>

	                        	</div>
								
								
	                        	<div class="text-center">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        						<button type="button" class="btn btn-primary" name="registerbutton" id="registerbutton">Register</button>
	        			</div>
					</form>
						
      </div>
    </div>
</div>
</div>



<!-- education Details -->
<div class="modal fade" id="education" tabindex="-1" role="dialog" aria-labelledby="personalModal" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content ">
      <div class="modal-header shadow-none ">
        <h5 class="modal-title text-warning " id="personalModal">Contact & Address Details of candidate</h5>
        <div id="errors"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div id="info"></div>
      <div class="modal-body">
	           	<form action="" method="POST" id="personalform">
					<table class="table">
                              <thead>
                                <tr>
                                  <th scope="col">Name of Examination</th>
                                  <th scope="col">Board/University</th>
                                  <th scope="col">Year of Passing</th>
                                  <th scope="col">Aggregate % of marks</th>
                                  <th scope="col">Division</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row">High School/10th</th>
                                  <td><input class="form-control input-lg" placeholder="" name="highboard" type="text" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="highpassyear" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="highperc" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="highdiv" type="text" ></td>
                                </tr>
                                <tr>
                                  <th scope="row">Intermediate/12th</th>
                                  <td><input class="form-control input-lg" placeholder="" name="interboard" type="text" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="interpassyear" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="interperc" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="interdiv" type="text" ></td>
                                </tr>
                                <tr>
                                  <th scope="row">Graduation</th>
                                  <td><input class="form-control input-lg" placeholder="" name="graduni" type="text" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="gradpassyear" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="gradperc" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="graddiv" type="text" ></td>
                                </tr>
                                <tr>
                                  <th scope="row">Post-Graduation</th>
                                  <td><input class="form-control input-lg" placeholder="" name="pguni" type="text" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="pgpassyear" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="pgperc" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="pgdiv" type="text" ></td>
                                </tr>
                                <tr>
                                  <th scope="row">B.Ed/B.Ed.SE(VI)</th>
                                  <td><input class="form-control input-lg" placeholder="" name="beduni" type="text" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="bedpassyear" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="bedperc" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="beddiv"  type="text" ></td>
                                </tr>
                                <tr>
                                  <th scope="row">Diploma in special education</th>
                                  <td><input class="form-control input-lg" placeholder="" name="dipouni" type="text" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="dipopassyear" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="dipoperc" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="dipodiv"  type="text" ></td>
                                </tr>
                                <tr>
                                  <th scope="row">Other</th>
                                  <td><input class="form-control input-lg" placeholder="" name="otherboard" type="text" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="otherpassyear" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="otherperc" type="number" ></td>
                                  <td><input class="form-control input-lg" placeholder="" name="otherdiv" type="text" ></td>
                                </tr>

                                 </tbody>
                            </table>
                        <div class="text-center">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        						<button type="button" class="btn btn-primary" name="registerbutton" id="registerbutton">Register</button>
	        			</div>
            				
				</form>
						
      </div>
    </div>
</div>
</div>


<!-- documents Details -->
<div class="modal fade" id="document" tabindex="-1" role="dialog" aria-labelledby="personalModal" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content ">
      <div class="modal-header shadow-none ">
        <h5 class="modal-title text-warning " id="personalModal">Contact & Address Details of candidate</h5>
        <div id="errors"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div id="info"></div>
      <div class="modal-body">
	           	<form action="" method="POST" id="personalform">
					<table class="table">
                              <thead>
                                <tr>
                                  <th scope="col">Documents</th>
                                  <th scope="col">Upload</th>
                                  <th scope="col">Preview</th>

                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row">PhotoGraph(JPEG/JPG only)</th>
                                  <td><input type='file' name='file' />
                                  	<button type="button" class="btn btn-primary my-2" name="registerbutton" id="registerbutton">Register</button></td>

                                </tr>
                                <tr>
                                  <th scope="row">Sign(JPEG/JPG only)</th>
                                  <td><input type='file' name='file' />
                                  <button type="button" class="btn btn-primary my-2" name="registerbutton" id="registerbutton">Register</button></td>

  
                                </tr>
                                <tr>
                                  <th scope="row">Matriculation Certificate(pdf only)</th>
                                  <td><input type='file' name='file' />
                                  <button type="button" class="btn btn-primary my-2" name="registerbutton" id="registerbutton">Register</button></td>
   

                                </tr>
                                <tr>
                                  <th scope="row">12th Certificate(pdf only)</th>
                                  <td><input type='file' name='file' />
                                  <button type="button" class="btn btn-primary my-2" name="registerbutton" id="registerbutton">Register</button></td>
                                 

                                </tr>
                                <tr>
                                  <th scope="row">Graduation(pdf only)</th>
                                  <td><input type='file' name='file' />
                                  	<button type="button" class="btn btn-primary my-2" name="registerbutton" id="registerbutton">Register</button></td>
                                  

                                </tr>
                                <tr>
                                  <th scope="row">Caste Certificate(pdf only)</th>
                                  <td><input type='file' name='file' />
                                  <button type="button" class="btn btn-primary my-2" name="registerbutton" id="registerbutton">Register</button></td>
                                 

                                </tr>
                                <tr>
                                  <th scope="row">Disability Certificate(pdf only)</th>
                                  <td><input type='file' name='file' />
                                  <button type="button" class="btn btn-primary my-2" name="registerbutton" id="registerbutton">Register</button></td>
                                  

                                </tr>

                                 </tbody>
                            </table>
                        <div class="text-center">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        						<button type="button" class="btn btn-primary" name="registerbutton" id="registerbutton">Register</button>
	        			</div>
            				
				</form>
						
      </div>
    </div>
</div>
</div>


<script type="text/javascript">
   $(document).ready(function() {
	
	

});



</script>



</body>
</html>